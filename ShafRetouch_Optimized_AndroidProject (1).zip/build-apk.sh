#!/usr/bin/env bash
# Shaf Retouch APK Build Script
echo "========================================"
echo " Building Shaf Retouch Native APK"
echo "========================================"

# Check for gradlew
if [ ! -f "gradlew" ]; then
    echo "Initializing Gradle Wrapper..."
    gradle wrapper --gradle-version 8.5
fi

chmod +x gradlew

echo "Compiling Debug APK..."
./gradlew assembleDebug

if [ $? -eq 0 ]; then
    echo ""
    echo "========================================"
    echo " SUCCESS! APK Built Successfully at:"
    echo " app/build/outputs/apk/debug/app-debug.apk"
    echo "========================================"
else
    echo "Build failed. Ensure Android SDK (API 34) and Java 17 are installed."
fi
