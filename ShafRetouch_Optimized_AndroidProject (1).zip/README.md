# Shaf Retouch - Android Native Project

This is the modernized, native-optimized Android project for **Shaf Retouch**.

## Native Performance Features Included:
- **Hardware Acceleration**: GPU layer acceleration configured in AndroidManifest and Window flags.
- **Offline Mode First**: WebView configured with `WebSettings.LOAD_CACHE_ELSE_NETWORK` to run seamlessly with zero network connectivity.
- **Modern Asset Loader**: Uses AndroidX `WebViewAssetLoader` to prevent CORS/file:// blocks.
- **Full File Picker & Camera Support**: Complete `WebChromeClient.onShowFileChooser` wired for gallery and camera uploads.
- **Separable 2-Pass Box Blur & Web Workers**: Multi-threaded pixel processing engine inside the bundled web assets.

## How to Build the APK:

### Option 1: Android Studio (Recommended)
1. Open Android Studio.
2. Select **Open an Existing Project** and choose this folder.
3. Wait for Gradle sync to complete.
4. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The APK will be located at:
   `app/build/outputs/apk/debug/app-debug.apk`

### Option 2: Command Line
```bash
chmod +x gradlew
./gradlew assembleDebug
```
The APK will be generated at `app/build/outputs/apk/debug/app-debug.apk`.

### Option 3: GitHub Actions Automated Build
Push this repo to GitHub, and the included `.github/workflows/build-apk.yml` will automatically build the APK on GitHub and give you a direct download link under the "Actions" tab!
